Para utilizar a aplicação basta abrir o projeto no Visual Studio.

 Após a execução do código basta clicar na tela, em 2 pontos quais quer e utilizar o botão DDA.


  Uma vez criada a linha, podem ser utilizadas as operações disponiveis na tela (Rotacao,escala,translação e reflexão)

  A linha pode ser recriada clicando em dois novos pontos (Ou ela criara de acordo com os dois ultimos pontos criados)


 Apos criar a linha basta colocar os valores de x min-max e y min-max dentro do intervalo permitido pelos pontos da linha.
 A partir dai você pode escolher usar o Cohen ou Liang para gerar a janela de corte.