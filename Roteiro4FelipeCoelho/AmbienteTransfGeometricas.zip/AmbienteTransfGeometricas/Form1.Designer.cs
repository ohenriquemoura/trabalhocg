﻿
namespace AmbienteTransfGeometricas
{
    partial class tela
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.painel = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.txtYmax = new System.Windows.Forms.TextBox();
            this.txtXmax = new System.Windows.Forms.TextBox();
            this.txtYmin = new System.Windows.Forms.TextBox();
            this.txtXmin = new System.Windows.Forms.TextBox();
            this.lbYmax = new System.Windows.Forms.Label();
            this.lbXmax = new System.Windows.Forms.Label();
            this.lbYmin = new System.Windows.Forms.Label();
            this.lbXmin = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.Bresenham = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.lbY2 = new System.Windows.Forms.Label();
            this.lbX2 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btApagar = new System.Windows.Forms.Button();
            this.btCor = new System.Windows.Forms.Button();
            this.btDesenhar = new System.Windows.Forms.Button();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.lbY1 = new System.Windows.Forms.Label();
            this.lbX1 = new System.Windows.Forms.Label();
            this.imagem = new System.Windows.Forms.PictureBox();
            this.cdlg = new System.Windows.Forms.ColorDialog();
            this.button8 = new System.Windows.Forms.Button();
            this.painel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imagem)).BeginInit();
            this.SuspendLayout();
            // 
            // painel
            // 
            this.painel.Controls.Add(this.button8);
            this.painel.Controls.Add(this.button7);
            this.painel.Controls.Add(this.txtYmax);
            this.painel.Controls.Add(this.txtXmax);
            this.painel.Controls.Add(this.txtYmin);
            this.painel.Controls.Add(this.txtXmin);
            this.painel.Controls.Add(this.lbYmax);
            this.painel.Controls.Add(this.lbXmax);
            this.painel.Controls.Add(this.lbYmin);
            this.painel.Controls.Add(this.lbXmin);
            this.painel.Controls.Add(this.button6);
            this.painel.Controls.Add(this.Bresenham);
            this.painel.Controls.Add(this.button5);
            this.painel.Controls.Add(this.txtY2);
            this.painel.Controls.Add(this.txtX2);
            this.painel.Controls.Add(this.lbY2);
            this.painel.Controls.Add(this.lbX2);
            this.painel.Controls.Add(this.button4);
            this.painel.Controls.Add(this.button3);
            this.painel.Controls.Add(this.button2);
            this.painel.Controls.Add(this.button1);
            this.painel.Controls.Add(this.btApagar);
            this.painel.Controls.Add(this.btCor);
            this.painel.Controls.Add(this.btDesenhar);
            this.painel.Controls.Add(this.txtY1);
            this.painel.Controls.Add(this.txtX1);
            this.painel.Controls.Add(this.lbY1);
            this.painel.Controls.Add(this.lbX1);
            this.painel.Dock = System.Windows.Forms.DockStyle.Right;
            this.painel.Location = new System.Drawing.Point(600, 0);
            this.painel.Name = "painel";
            this.painel.Size = new System.Drawing.Size(200, 450);
            this.painel.TabIndex = 0;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(14, 211);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(86, 23);
            this.button7.TabIndex = 30;
            this.button7.Text = "Cohen";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.btCohen_Click);
            // 
            // txtYmax
            // 
            this.txtYmax.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYmax.Location = new System.Drawing.Point(117, 178);
            this.txtYmax.Margin = new System.Windows.Forms.Padding(2);
            this.txtYmax.Name = "txtYmax";
            this.txtYmax.Size = new System.Drawing.Size(76, 28);
            this.txtYmax.TabIndex = 29;
            this.txtYmax.Text = "0";
            // 
            // txtXmax
            // 
            this.txtXmax.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXmax.Location = new System.Drawing.Point(7, 178);
            this.txtXmax.Margin = new System.Windows.Forms.Padding(2);
            this.txtXmax.Name = "txtXmax";
            this.txtXmax.Size = new System.Drawing.Size(76, 28);
            this.txtXmax.TabIndex = 28;
            this.txtXmax.Text = "0";
            // 
            // txtYmin
            // 
            this.txtYmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYmin.Location = new System.Drawing.Point(117, 119);
            this.txtYmin.Margin = new System.Windows.Forms.Padding(2);
            this.txtYmin.Name = "txtYmin";
            this.txtYmin.Size = new System.Drawing.Size(76, 28);
            this.txtYmin.TabIndex = 27;
            this.txtYmin.Text = "0";
            // 
            // txtXmin
            // 
            this.txtXmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXmin.Location = new System.Drawing.Point(9, 119);
            this.txtXmin.Margin = new System.Windows.Forms.Padding(2);
            this.txtXmin.Name = "txtXmin";
            this.txtXmin.Size = new System.Drawing.Size(76, 28);
            this.txtXmin.TabIndex = 26;
            this.txtXmin.Text = "0";
            // 
            // lbYmax
            // 
            this.lbYmax.AutoSize = true;
            this.lbYmax.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbYmax.Location = new System.Drawing.Point(114, 152);
            this.lbYmax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbYmax.Name = "lbYmax";
            this.lbYmax.Size = new System.Drawing.Size(58, 24);
            this.lbYmax.TabIndex = 25;
            this.lbYmax.Text = "Ymax";
            // 
            // lbXmax
            // 
            this.lbXmax.AutoSize = true;
            this.lbXmax.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbXmax.Location = new System.Drawing.Point(5, 152);
            this.lbXmax.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbXmax.Name = "lbXmax";
            this.lbXmax.Size = new System.Drawing.Size(60, 24);
            this.lbXmax.TabIndex = 24;
            this.lbXmax.Text = "Xmax";
            // 
            // lbYmin
            // 
            this.lbYmin.AutoSize = true;
            this.lbYmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbYmin.Location = new System.Drawing.Point(114, 93);
            this.lbYmin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbYmin.Name = "lbYmin";
            this.lbYmin.Size = new System.Drawing.Size(53, 24);
            this.lbYmin.TabIndex = 23;
            this.lbYmin.Text = "Ymin";
            // 
            // lbXmin
            // 
            this.lbXmin.AutoSize = true;
            this.lbXmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbXmin.Location = new System.Drawing.Point(5, 93);
            this.lbXmin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbXmin.Name = "lbXmin";
            this.lbXmin.Size = new System.Drawing.Size(55, 24);
            this.lbXmin.TabIndex = 22;
            this.lbXmin.Text = "Xmin";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(25, 324);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 36);
            this.button6.TabIndex = 17;
            this.button6.Text = "Circulo";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btCirculo_Click);
            // 
            // Bresenham
            // 
            this.Bresenham.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bresenham.Location = new System.Drawing.Point(25, 282);
            this.Bresenham.Name = "Bresenham";
            this.Bresenham.Size = new System.Drawing.Size(75, 36);
            this.Bresenham.TabIndex = 16;
            this.Bresenham.Text = "Bresenham";
            this.Bresenham.UseVisualStyleBackColor = true;
            this.Bresenham.Click += new System.EventHandler(this.btBress_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(25, 364);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 36);
            this.button5.TabIndex = 15;
            this.button5.Text = "Escala -";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.escalaDown);
            // 
            // txtY2
            // 
            this.txtY2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtY2.Location = new System.Drawing.Point(152, 28);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(45, 31);
            this.txtY2.TabIndex = 14;
            this.txtY2.Text = "0";
            // 
            // txtX2
            // 
            this.txtX2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtX2.Location = new System.Drawing.Point(106, 28);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(40, 31);
            this.txtX2.TabIndex = 13;
            this.txtX2.Text = "0";
            // 
            // lbY2
            // 
            this.lbY2.AutoSize = true;
            this.lbY2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.lbY2.Location = new System.Drawing.Point(147, 0);
            this.lbY2.Name = "lbY2";
            this.lbY2.Size = new System.Drawing.Size(41, 25);
            this.lbY2.TabIndex = 12;
            this.lbY2.Text = "Y2";
            // 
            // lbX2
            // 
            this.lbX2.AutoSize = true;
            this.lbX2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbX2.Location = new System.Drawing.Point(101, 0);
            this.lbX2.Name = "lbX2";
            this.lbX2.Size = new System.Drawing.Size(40, 25);
            this.lbX2.TabIndex = 11;
            this.lbX2.Text = "X2";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(106, 364);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 36);
            this.button4.TabIndex = 10;
            this.button4.Text = "Translação";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.translacao);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(106, 406);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 36);
            this.button3.TabIndex = 9;
            this.button3.Text = "Reflexão";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.reflexao);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(25, 406);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 36);
            this.button2.TabIndex = 8;
            this.button2.Text = "Escala +";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.escala);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(106, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 36);
            this.button1.TabIndex = 7;
            this.button1.Text = "Rotação";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.rotacao);
            // 
            // btApagar
            // 
            this.btApagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btApagar.Location = new System.Drawing.Point(106, 240);
            this.btApagar.Name = "btApagar";
            this.btApagar.Size = new System.Drawing.Size(75, 36);
            this.btApagar.TabIndex = 6;
            this.btApagar.Text = "Apagar";
            this.btApagar.UseVisualStyleBackColor = true;
            this.btApagar.Click += new System.EventHandler(this.btApagar_Click);
            // 
            // btCor
            // 
            this.btCor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCor.Location = new System.Drawing.Point(108, 282);
            this.btCor.Name = "btCor";
            this.btCor.Size = new System.Drawing.Size(73, 36);
            this.btCor.TabIndex = 5;
            this.btCor.Text = "Cor";
            this.btCor.UseVisualStyleBackColor = true;
            this.btCor.Click += new System.EventHandler(this.btCor_Click);
            // 
            // btDesenhar
            // 
            this.btDesenhar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDesenhar.Location = new System.Drawing.Point(25, 240);
            this.btDesenhar.Name = "btDesenhar";
            this.btDesenhar.Size = new System.Drawing.Size(75, 36);
            this.btDesenhar.TabIndex = 4;
            this.btDesenhar.Text = "DDA";
            this.btDesenhar.UseVisualStyleBackColor = true;
            this.btDesenhar.Click += new System.EventHandler(this.drawLineAtiv1);
            // 
            // txtY1
            // 
            this.txtY1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtY1.Location = new System.Drawing.Point(47, 28);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(41, 31);
            this.txtY1.TabIndex = 3;
            this.txtY1.Text = "0";
            // 
            // txtX1
            // 
            this.txtX1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtX1.Location = new System.Drawing.Point(1, 28);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(40, 31);
            this.txtX1.TabIndex = 2;
            this.txtX1.Text = "0";
            // 
            // lbY1
            // 
            this.lbY1.AutoSize = true;
            this.lbY1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.lbY1.Location = new System.Drawing.Point(47, 0);
            this.lbY1.Name = "lbY1";
            this.lbY1.Size = new System.Drawing.Size(41, 25);
            this.lbY1.TabIndex = 1;
            this.lbY1.Text = "Y1";
            // 
            // lbX1
            // 
            this.lbX1.AutoSize = true;
            this.lbX1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbX1.Location = new System.Drawing.Point(1, 0);
            this.lbX1.Name = "lbX1";
            this.lbX1.Size = new System.Drawing.Size(40, 25);
            this.lbX1.TabIndex = 0;
            this.lbX1.Text = "X1";
            // 
            // imagem
            // 
            this.imagem.BackColor = System.Drawing.Color.White;
            this.imagem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.imagem.Location = new System.Drawing.Point(0, 0);
            this.imagem.Name = "imagem";
            this.imagem.Size = new System.Drawing.Size(600, 450);
            this.imagem.TabIndex = 1;
            this.imagem.TabStop = false;
            this.imagem.MouseClick += new System.Windows.Forms.MouseEventHandler(this.imagem_MouseClick);
            this.imagem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.imagem_MouseMove);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(106, 211);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(86, 23);
            this.button8.TabIndex = 31;
            this.button8.Text = "Liang";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Liang_Click);
            // 
            // tela
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.imagem);
            this.Controls.Add(this.painel);
            this.Name = "tela";
            this.Text = "Roteiro 3 – Algoritmo Bresenham";
            this.painel.ResumeLayout(false);
            this.painel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imagem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel painel;
        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.Label lbY1;
        private System.Windows.Forms.Label lbX1;
        private System.Windows.Forms.PictureBox imagem;
        private System.Windows.Forms.Button btApagar;
        private System.Windows.Forms.Button btCor;
        private System.Windows.Forms.Button btDesenhar;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.ColorDialog cdlg;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.Label lbY2;
        private System.Windows.Forms.Label lbX2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button Bresenham;
        private System.Windows.Forms.TextBox txtYmax;
        private System.Windows.Forms.TextBox txtXmax;
        private System.Windows.Forms.TextBox txtYmin;
        private System.Windows.Forms.TextBox txtXmin;
        private System.Windows.Forms.Label lbYmax;
        private System.Windows.Forms.Label lbXmax;
        private System.Windows.Forms.Label lbYmin;
        private System.Windows.Forms.Label lbXmin;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
    }
}

